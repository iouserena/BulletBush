﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Format_Cells : MonoBehaviour
{

    public GameObject left_Wall;
    public GameObject right_Wall;
    public GameObject top_Wall;
    public GameObject bottom_Wall;
}
