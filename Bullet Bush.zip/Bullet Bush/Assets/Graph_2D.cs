﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Graph_2D : MonoBehaviour
{

    public Transform pointPrefab;

    [SerializeField]
    private int amplitude = 1;

    [SerializeField]
    private float frequency = 0.1f;


    void Update()
    {
        float x = Mathf.Cos(Time.time * frequency) * amplitude;
        float y = Mathf.Sin(Time.time * frequency) * amplitude;
        float z = transform.position.z;

        transform.position = new Vector3(x, y, z);
    }


}