﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class Button_Methods : MonoBehaviour
{
    public void startGame()
    { SceneManager.LoadScene("Intro_Scene"); }
}
