﻿public enum GraphFunctionName {
	Sine, Sine2D, MultiSine, MultiSine2D,
	Ripple, Cylinder, Sphere, Torus
}