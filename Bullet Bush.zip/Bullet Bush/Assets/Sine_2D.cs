﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sine_2D : MonoBehaviour
{
    public Transform pointPrefab;

    [Range(10, 100)]
    public int resolution = 10;
    public float step = 5.0f;
    public int height = 0;

    Transform[] points;

    void Awake()
    {
        //float step = 2f / resolution;
        //Vector3 scale = Vector3.one * step;
        //Vector3 position;
        Vector2 scale = Vector2.one * step;
        Vector2 position;
        position.y = 0f;
        //position.z = 0f;
        points = new Transform[resolution];
        for (int i = 0; i < points.Length; i++)
        {
            Transform point = Instantiate(pointPrefab);
            position.x = (i + 0.5f) * step - 1f;
            point.localPosition = position;
            point.localScale = scale;
            point.SetParent(transform, false);
            points[i] = point;
        }
    }

    void Update()
    {
        for (int i = 0; i < points.Length; i++)
        {
            Transform point = points[i];
            Vector2 position = point.localPosition;
            position.y = Mathf.Sin(Mathf.PI * (position.x + Time.time))* height; // added height
            point.localPosition = position;
        }
    }
}
